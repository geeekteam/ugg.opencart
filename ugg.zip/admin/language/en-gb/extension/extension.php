<?php
// Heading
$_['heading_title']  = 'Extensions';

// Text
$_['text_success']   = 'Success: You have modified extensions!';
$_['text_list']      = 'Extension List';
$_['text_type']      = 'Choose the extension type';
$_['text_filter']    = 'Filter';
$_['text_analytics'] = 'Analytics';
$_['text_captcha']   = 'Captcha';
$_['text_dashboard'] = 'Dashboard';
$_['text_feed']      = 'Feeds';
$_['text_fraud']     = 'Anti-Fraud';
$_['text_module']    = 'Modules';
$_['text_content']   = 'Content Modules';
$_['text_menu']      = 'Menu Modules';
$_['text_payment']   = 'Payments';
$_['text_shipping']  = 'Shipping';
$_['text_theme']     = 'Themes';
$_['text_total']     = 'Order Totals';